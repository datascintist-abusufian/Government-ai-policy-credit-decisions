# Data

The raw data are **not** included in this repository. Download them from Mendeley Data.

| Item | Value |
|---|---|
| Dataset | *Dataset from the US Peer-to-peer Lending Platform with Macroeconomic Variables* |
| Author | A. Nigmonov |
| Version | **3** (published 30 September 2021). Version 4 (29 November 2021) was **not** used |
| DOI | [10.17632/wb3ndt69gf.3](https://doi.org/10.17632/wb3ndt69gf.3) |
| License | CC BY 4.0 |
| Records | 2,703,430 LendingClub loans, originated Aug 2012 – Dec 2019 (195 columns) |

## Expected layout

```
data/
└── raw/
    └── wb3ndt69gf-3.zip          # downloaded archive (keep this name)
        ├── P2P_Macro_Data.dta    # ~2.8 GB, extracted automatically by the notebook
        ├── P2P_Macro_Data.zip
        ├── P2P_Macro_Codes.do    # source construction code (read by the leakage audit)
        └── Labels.do
```

The notebook extracts `P2P_Macro_Data.dta` to `data/raw/wb3ndt69gf-3_extracted/`. It also reads `P2P_Macro_Codes.do` and `Labels.do` directly from the zip during the temporal-alignment audit (Part C).

To store the data elsewhere, set `GOV_AI_DATA_DIR` to the folder that contains `wb3ndt69gf-3.zip`.

## Notes on source fields

- `badloan` in the source data also codes `Late (16–30)` and `Late (31–120)` as bad. The revised endpoint uses **only** `Charged Off` and `Default` as default (Appendix A of the paper).
- `last_date` is built from `last_pymnt_d` (last payment received). It is **not** a default-event date.
- The source `month`, `quarter` and macroeconomic fields (`unemployment`, `unem_rate`, `gdpindex`, `gdpreal`, `gdpcontrib`, `cpi`, `inf`, `FEDFUNDS`, `gdppercap`, `riskprem`) are keyed to `last_date` × state. The notebook rebuilds them from `issue_date` × `addr_state`.
