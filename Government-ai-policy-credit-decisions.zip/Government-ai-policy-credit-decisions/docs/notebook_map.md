# Notebook → manuscript map

Notebook: `notebooks/NeurIPS_2026_CameraReady_Reanalysis.ipynb`. Run it top to bottom.

## 0. Setup

| Step | What it does |
|---|---|
| Configuration | Sets `DATA_DIR`, `ZIP_PATH` and `EXTRACT_DIR` (override with `GOV_AI_DATA_DIR`) |
| Archive listing / extraction | Lists the zip and extracts `P2P_Macro_Data.dta` |

## A. Outcome definition and cohort construction → §2.4–2.5, Table 1, Appendix A

| Step | What it does | Paper |
|---|---|---|
| W1 Step 1 | Scans the 195 columns for outcome and timing variables | §2.4 |
| W1 Steps 2–4 | Inspects outcome/timing fields and Stata labels; checks `badloan` ↔ `loan_status` and `last_date` ↔ `last_pymnt_d` | Appendix A, status-mapping table |
| W1 Steps 5–8 | Status × issue year for 36-month loans; follow-up timing; source `.do` code; dataset snapshot dates | §2.4 |
| W1 Steps 9–13 | Month-level completeness for 2014–2015; unresolved 2015 loans; charge-off timing; search for an event-date field | Rationale for excluding September 2015 |
| W1 Steps 14–15 | Candidate fixed-vintage designs (superseded by Step 18) | — |
| W1 Steps 16–17 | Flags post-origination columns; audits the 41-feature origination-time set | §2.4 |
| W1 Steps 18–19 | **Final 2015 fixed-horizon split** and modelling frame (264,344 × 46) | **Table 1**, Appendix A revised-split table |

## B. Provisional models on source-aligned fields — superseded

| Step | What it does | Paper |
|---|---|---|
| W1 Steps 20–22 | Predictor typing and training-only preprocessing (107 features, source fields) | — |
| W1 Steps 23–25 | SGD / HistGB / MLP × 3 seeds on source-aligned fields | **Post-origination-field diagnostic** (§2.5 paragraph: AUC 0.7413 / 0.7517 / 0.7697) |
| Steps 26–34 | DeLong, skill, recalibration, thresholds, MLP bootstrap, grade audit on leaky features | Not used (superseded by Part D) |

## C. Temporal-alignment (leakage) audit → §2.4, §3.4, Appendix A

| Step | What it does | Paper |
|---|---|---|
| W6 Step 35B | Reads `P2P_Macro_Codes.do` from the zip | §2.4 |
| W6 Step 36 | Shows `month`/`quarter` match the last-payment month 100% of the time (issue month only 25.7%); macro fields keyed to last-payment month × state | §2.4, Appendix A |
| W6 Step 37 | Builds a conflict-free state × month macro lookup and realigns it to `issue_date` × state | §2.4 |
| W6 Step 38 | Characterises origination-aligned `unem_rate`; training 75th percentile = **6.20%**; test stress n = 3,069 (16.13% default) | **§3.4 Stress definition** |

## D. Leakage-free rebuild and final results → §3, Tables 2–6

| Step | What it does | Paper |
|---|---|---|
| Step 39 | Origination-aligned feature frame (month and quarter from `issue_date`; macro from issue month × state) | §2.4 |
| Step 40 | Removes zero-variance `riskprem`; training-only preprocessing → **38 raw / 106 encoded** features | §2.4 |
| Steps 41–43 | SGD logistic, HistGB and MLP × seeds {17, 42, 2026} | **Table 2** (model comparison) |
| Step 44 | Paired DeLong tests on the shared test set | §3.2 text (ΔAUC, 95% CI, p) |
| Final W2 | Brier/log-loss skill vs. constant prevalence; validation-fitted logistic recalibration; intercept, slope and ECE | **Table 3**, §3.3 text |
| Final W4 | Part A: thresholds for all models at r ∈ {5, 10, 20}. Part B: HistGB cost continuum r ∈ {2,…,20}, 300 bootstrap resamples with the threshold re-selected inside each | **Table 4**, **Table 6** |
| Final W5 | Predeclared grade A–G audit, recalibrated HistGB, r = 10, t* = 0.0909, 500 within-grade bootstrap resamples | **Table 5**, §3.6 |

## Fixed settings

- Seeds: `SEEDS = [17, 42, 2026]`
- Cost ratios: `COST_RATIOS = [5, 10, 20]`; continuum `R_CURVE = [2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 20]`
- Bootstrap: Final W4 `B = 300` (`default_rng(26044)`); Final W5 `B_W5 = 500`
